AYMann Productions website starter
===================================

Files:
- index.html  = website
- style.css   = design
- logo.jpeg   = your uploaded AYMann Productions logo

How to publish for free:
1. Create a free GitHub account.
2. Create a new repository named "aymann-productions".
3. Upload index.html, style.css and logo.jpeg.
4. In the repository, open Settings > Pages.
5. Choose "Deploy from a branch", select the main branch and / (root), then Save.
6. GitHub will give you a free website address ending in github.io.

Before launch:
- Replace "Upcoming Stage Play" and the TBD event cards with your real productions.
- Add your ticket-service links.
- Add your Facebook page URL.
- Replace the merchandise placeholders with your actual products.
- The sample form uses email submission. For a more reliable online form with file uploads, connect a free form service later.
